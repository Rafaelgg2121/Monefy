package com.qa.stepdef;

import com.qa.pages.HomePage;
import com.qa.pages.IncomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class IncomeStepDef {

    @Given("^The aplication is started$")
    public void theAplicationIsStarted() throws InterruptedException {
        new HomePage().IncomeButtonClick();
    }
    @When("^I click Income button$")
    public void iClickIncomeButton() throws InterruptedException {
        new HomePage().IncomeButtonClick();
    }
    @When("^I enter an \"([^\"]*)\"$")
    public void iEnterAn(String amount) throws InterruptedException {
        new IncomePage().enterIncomeAmount(amount);
    }
    @When("^I choose a category$")
    public void iChooseA() {
        new IncomePage().chooseDepositCategoryOption();
    }
    @Then("^I should watch my income added on home screen$")
    public void iShouldWatchMyIncomeAddedOnHomeScreen() {
        new HomePage().getIncomeAmountText();
    }
}
