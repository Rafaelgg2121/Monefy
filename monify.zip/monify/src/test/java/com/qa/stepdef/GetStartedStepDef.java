package com.qa.stepdef;

import com.qa.pages.GetStartedPage;
import com.qa.pages.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetStartedStepDef {

    @When("^I'm getting staterd the aplication$")
    public void iMGettingStaterdTheAplication() {
        // Write code here that turns the phrase above into concrete actions
    }
    @And("^I click Get Started button$")
    public void iClickGetStartedButton() throws InterruptedException {
        new GetStartedPage().GetStartedButtonClic();

    }
    @And("^I clic Amazing button$")
    public void iClicAmazingButton() throws InterruptedException {
        new GetStartedPage().AmazingButtonClic();

    }
    @And("^I clic I'm Ready button$")
    public void iClicIMReadyButton() throws InterruptedException {
        new GetStartedPage().ImReadyButtonClic();

    }
    @And("^I clic close button$")
    public void iClicCloseButton() throws InterruptedException {
        new GetStartedPage().GetStartedCloseButton();

    }
    @Then("^Aplication should start successfully$")
    public void aplicationShouldStartSuccessfully() {
        new HomePage().getIncomeAmountText();
    }
}
