package com.qa.pages;

import com.qa.utils.TestUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class GetStartedPage extends BasePage{

    TestUtils utils = new TestUtils();

    @AndroidFindBy (accessibility = "com.monefy.app.lite:id/buttonClose")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/buttonContinue")
    private MobileElement getStartedButton;

    @AndroidFindBy (accessibility = "com.monefy.app.lite:id/buttonClose")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/buttonClose")
    private MobileElement closeButton;

    public GetStartedPage(){
    }

    public GetStartedPage GetStartedButtonClic() throws InterruptedException {
        click(getStartedButton);
        return this;
    }

    public GetStartedPage AmazingButtonClic() throws InterruptedException {
        click(getStartedButton);
        return this;
    }

    public GetStartedPage ImReadyButtonClic() throws InterruptedException {
        click(getStartedButton);
        return this;
    }

    public GetStartedPage GetStartedCloseButton() throws InterruptedException {
        click(closeButton);
        return this;
    }
}
