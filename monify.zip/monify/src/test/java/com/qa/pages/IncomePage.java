package com.qa.pages;

import com.qa.utils.TestUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class IncomePage extends BasePage {

    TestUtils utils = new TestUtils();

    @AndroidFindBy (id = "com.monefy.app.lite:id/amount_text")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/amount_text")
    private MobileElement amountInput;

    @AndroidFindBy (id = "com.monefy.app.lite:id/textViewNote")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/textViewNote")
    private MobileElement notesInput;

    @AndroidFindBy (id = "com.monefy.app.lite:id/keyboard_action_button")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/keyboard_action_button")
    private MobileElement chooseCategoryButton;

    @AndroidFindBy (xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.GridView/android.widget.FrameLayout[1]/android.widget.LinearLayout\n")
    //@iOSXCUITFindBy (id = "com.monefy.app.lite:id/keyboard_action_button")
    private MobileElement depositsButton;

    public IncomePage(){
    }

    public IncomePage enterIncomeAmount(String amount) throws InterruptedException {
        sendKeys(amountInput, amount, "Actual amount is " + amount);
        return this;
    }

    public IncomePage chooseDepositCategoryOption(){
        click(chooseCategoryButton);
        click(depositsButton);
        return this;
    }

    public String getAmountInputText() {
        String amountText = getText(amountInput, "Actual Balance is - ");
        return amountText;
    }
}
