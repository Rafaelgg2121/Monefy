package com.qa.pages;

import com.qa.utils.TestUtils;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class HomePage extends BasePage{

    TestUtils utils = new TestUtils();

    @AndroidFindBy(id = "com.monefy.app.lite:id/income_button")
    @iOSXCUITFindBy(id = "com.monefy.app.lite:id/income_button")
    private MobileElement incomeButton;

    @AndroidFindBy (id = "com.monefy.app.lite:id/expense_button")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/expense_button")
    private MobileElement expenseButton;

    @AndroidFindBy (id = "com.monefy.app.lite:id/income_amount_text")
    @iOSXCUITFindBy (id = "com.monefy.app.lite:id/income_amount_text")
    private MobileElement incomeAmountText;

    public HomePage(){
    }

    public IncomePage IncomeButtonClick() throws InterruptedException {
        click(incomeButton);
        return new IncomePage();
    }

    public HomePage ExpenseButtonClick() throws InterruptedException {
        click(expenseButton);
        return this;
    }

    public String getIncomeAmountText() {
        String amountText = getText(incomeAmountText, "Actual Balance is - ");
        return amountText;
    }
}
